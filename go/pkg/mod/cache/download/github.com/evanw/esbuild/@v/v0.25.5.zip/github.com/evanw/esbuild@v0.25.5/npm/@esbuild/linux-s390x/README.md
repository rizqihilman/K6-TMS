# esbuild

This is the Linux IBM Z 64-bit Big Endian binary for esbuild, a JavaScript bundler and minifier. See https://github.com/evanw/esbuild for details.
