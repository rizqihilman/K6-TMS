# esbuild

This is a WebAssembly shim for esbuild on Android ARM. See https://github.com/evanw/esbuild for details.
