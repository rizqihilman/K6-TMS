---
name: New issue
about: This is the template for new issues.
title: ''
labels: ''
assignees: ''

---

<!--
When reporting a bug or requesting a feature, please do the following:

* Describe what esbuild is doing incorrectly and what it should be doing instead.

* Provide a way to reproduce the issue. The best way to do this is to demonstrate the issue on the playground (https://esbuild.github.io/try/) and paste the URL here. A link to a minimal code sample with instructions for how to reproduce the issue may also work. Issues without a way to reproduce them may be closed.
-->
