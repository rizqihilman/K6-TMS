# esbuild

This is the WASI (WebAssembly System Interface) preview 1 binary for esbuild, a JavaScript bundler and minifier. See https://github.com/evanw/esbuild for details.
