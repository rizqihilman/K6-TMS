// Package pke provides a variety of public key encryption mechanisms.
package pke
