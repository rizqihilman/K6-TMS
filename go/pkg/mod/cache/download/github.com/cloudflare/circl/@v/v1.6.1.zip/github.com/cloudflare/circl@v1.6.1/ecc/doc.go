// Package ecc provides implementation of arithmetic on some elliptic curves.
package ecc
