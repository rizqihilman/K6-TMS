// Code generated from params.templ.go. DO NOT EDIT.

package internal

const (
	Name          = "Dilithium5"
	K             = 8
	L             = 7
	Eta           = 2
	DoubleEtaBits = 3
	Omega         = 75
	Tau           = 60
	Gamma1Bits    = 19
	Gamma2        = 261888
	NIST          = false
	TRSize        = 32
	CTildeSize    = 32
)
