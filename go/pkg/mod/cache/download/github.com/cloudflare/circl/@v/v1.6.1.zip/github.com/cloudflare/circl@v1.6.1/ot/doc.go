// Package ot provides oblivious-transfer protocols.
package ot
