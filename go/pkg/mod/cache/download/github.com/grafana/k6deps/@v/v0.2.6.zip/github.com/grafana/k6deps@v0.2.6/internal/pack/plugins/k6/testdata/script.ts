/// @ts-ignore
import { sleep } from "k6";

export { sleep };
