// Package k6deps contains the data model of the k6 script dependencies and the operations related to them.
package k6deps
