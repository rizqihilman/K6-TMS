// SPDX-FileCopyrightText: 2023 Raintank, Inc. dba Grafana Labs
//
// SPDX-License-Identifier: AGPL-3.0-only

declare module "*.md"
declare module "*.svg"
declare module "*.jpg"
declare module "*.jpeg"
declare module "*.png"
