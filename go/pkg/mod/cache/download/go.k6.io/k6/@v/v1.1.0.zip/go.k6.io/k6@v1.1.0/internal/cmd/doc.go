// Package cmd implements the command-line interface of k6.
package cmd
