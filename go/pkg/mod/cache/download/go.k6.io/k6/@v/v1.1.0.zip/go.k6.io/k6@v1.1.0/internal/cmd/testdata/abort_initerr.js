import exec from 'k6/execution';
exec.test.abort();
