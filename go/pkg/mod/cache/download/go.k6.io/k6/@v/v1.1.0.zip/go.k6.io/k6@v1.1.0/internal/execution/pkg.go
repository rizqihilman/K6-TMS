// Package execution contains most of the components that schedule, execute and
// control individual k6 tests.
package execution

// TODO: move ExecutionSegment and ESS here

// TODO: move execotors interfaces here and implementations in a sub-folder
// TODO: move the execution state here
