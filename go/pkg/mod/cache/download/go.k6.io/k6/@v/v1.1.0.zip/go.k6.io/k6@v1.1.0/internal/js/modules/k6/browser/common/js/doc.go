// Package js provides JavaScript code that the browser module evaluates on the browser.
// The common package uses this package.
// `injected_script.js` is injected into each execution context.
package js
