function coolThrow(s: string) {
    throw "cool "+ s
}
export default () => {
    coolThrow("is cool")
};
