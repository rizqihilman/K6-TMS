// Package tests provides integration tests.
// The `testBrowser` type enables us to test the browser module with a real browser.
package tests
