Main features

- Create new extension skeleton (project scaffolding)
- Build k6 with extensions
- Run k6 with extensions
- Check the extension for compliance (lint)
- Provide reusable GitHub workflows
- Distribute xk6 as a Dev Container Feature
