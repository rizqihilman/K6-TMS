Use with Development Containers

Get started developing k6 extensions quickly!

xk6 is now a [Development containers] feature, meaning you can develop without installing any tooling or xk6.

Check out the [k6 extension development quickstart guide] and [k6 extension development tutorial] for details.

[Development containers]: https://containers.dev/
[k6 extension development quickstart guide]: https://github.com/grafana/xk6/wiki/k6-extension-development-quick-start-guide
[k6 extension development tutorial]: https://github.com/grafana/xk6/wiki/k6-extension-development-tutorial
